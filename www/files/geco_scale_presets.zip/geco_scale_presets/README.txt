GeCo Scale Presets
==================
Total presets: 77

01_Church_Modes_from_C_Major
  - Ionian_C.txt | Start Note: C | Sequence: 2 2 1 2 2 2 1
  - Dorian_D.txt | Start Note: D | Sequence: 2 1 2 2 2 1 2
  - Phrygian_E.txt | Start Note: E | Sequence: 1 2 2 2 1 2 2
  - Lydian_F.txt | Start Note: F | Sequence: 2 2 2 1 2 2 1
  - Mixolydian_G.txt | Start Note: G | Sequence: 2 2 1 2 2 1 2
  - Aeolian_A.txt | Start Note: A | Sequence: 2 1 2 2 1 2 2
  - Locrian_B.txt | Start Note: B | Sequence: 1 2 2 1 2 2 2

02_Modes_of_A_Harmonic_Minor
  - Harmonic_Minor_A.txt | Start Note: A | Sequence: 2 1 2 2 1 3 1
  - Locrian_sharp6_B.txt | Start Note: B | Sequence: 1 2 2 1 3 1 2
  - Ionian_sharp5_C.txt | Start Note: C | Sequence: 2 2 1 3 1 2 1
  - Dorian_sharp4_D.txt | Start Note: D | Sequence: 2 1 3 1 2 1 2
  - Phrygian_Dominant_E.txt | Start Note: E | Sequence: 1 3 1 2 1 2 2
  - Lydian_sharp2_F.txt | Start Note: F | Sequence: 3 1 2 1 2 2 1
  - Ultra_Locrian_Gsharp.txt | Start Note: G# | Sequence: 1 2 1 2 2 1 3

03_Modes_of_A_Melodic_Minor
  - Melodic_Minor_A.txt | Start Note: A | Sequence: 2 1 2 2 2 2 1
  - Dorian_b2_B.txt | Start Note: B | Sequence: 1 2 2 2 2 1 2
  - Lydian_Augmented_C.txt | Start Note: C | Sequence: 2 2 2 2 1 2 1
  - Lydian_Dominant_D.txt | Start Note: D | Sequence: 2 2 2 1 2 1 2
  - Mixolydian_b6_E.txt | Start Note: E | Sequence: 2 2 1 2 1 2 2
  - Locrian_sharp2_Fsharp.txt | Start Note: F# | Sequence: 2 1 2 1 2 2 2
  - Altered_Super_Locrian_Gsharp.txt | Start Note: G# | Sequence: 1 2 1 2 2 2 2

04_Pentatonic_and_Blues_C
  - Major_Pentatonic_C.txt | Start Note: C | Sequence: 2 2 3 2 3
  - Minor_Pentatonic_C.txt | Start Note: C | Sequence: 3 2 2 3 2
  - Major_Blues_C.txt | Start Note: C | Sequence: 2 1 1 3 2 3
  - Minor_Blues_C.txt | Start Note: C | Sequence: 3 2 1 1 3 2

05_Bebop_C
  - Major_Bebop_C.txt | Start Note: C | Sequence: 2 2 1 2 1 1 2 1
  - Dominant_Bebop_C.txt | Start Note: C | Sequence: 2 2 1 2 2 1 1 1
  - Minor_Bebop_Dorian_Bebop_C.txt | Start Note: C | Sequence: 2 1 2 2 1 1 1 2
  - Melodic_Minor_Bebop_C.txt | Start Note: C | Sequence: 2 1 2 1 1 2 2 1
  - Harmonic_Minor_Bebop_C.txt | Start Note: C | Sequence: 2 1 2 2 1 1 2 1
  - Bebop_Locrian_C.txt | Start Note: C | Sequence: 1 2 2 1 1 1 2 2
  - Bebop_Altered_C.txt | Start Note: C | Sequence: 1 2 1 2 2 2 1 1
  - Half_Whole_Bebop_Diminished_C.txt | Start Note: C | Sequence: 1 2 1 2 1 2 1 2

06_Symmetric_C
  - Whole_Tone_C.txt | Start Note: C | Sequence: 2 2 2 2 2 2
  - Chromatic_C.txt | Start Note: C | Sequence: 1 1 1 1 1 1 1 1 1 1 1 1
  - Diminished_Whole_Half_C.txt | Start Note: C | Sequence: 2 1 2 1 2 1 2 1
  - Diminished_Half_Whole_C.txt | Start Note: C | Sequence: 1 2 1 2 1 2 1 2

07_Neapolitan_Major_Modes
  - Neapolitan_Major_C.txt | Start Note: C | Sequence: 1 2 2 2 2 2 1
  - Neapolitan_Major_Mode_II_Db.txt | Start Note: Db | Sequence: 2 2 2 2 2 1 1
  - Neapolitan_Major_Mode_III_Eb.txt | Start Note: Eb | Sequence: 2 2 2 2 1 1 2
  - Neapolitan_Major_Mode_IV_F.txt | Start Note: F | Sequence: 2 2 2 1 1 2 2
  - Neapolitan_Major_Mode_V_G.txt | Start Note: G | Sequence: 2 2 1 1 2 2 2
  - Neapolitan_Major_Mode_VI_A.txt | Start Note: A | Sequence: 2 1 1 2 2 2 2
  - Neapolitan_Major_Mode_VII_B.txt | Start Note: B | Sequence: 1 1 2 2 2 2 2

08_Neapolitan_Minor_Modes
  - Neapolitan_Minor_C.txt | Start Note: C | Sequence: 1 2 2 2 1 3 1
  - Neapolitan_Minor_Mode_II_Db.txt | Start Note: Db | Sequence: 2 2 2 1 3 1 1
  - Neapolitan_Minor_Mode_III_Eb.txt | Start Note: Eb | Sequence: 2 2 1 3 1 1 2
  - Neapolitan_Minor_Mode_IV_F.txt | Start Note: F | Sequence: 2 1 3 1 1 2 2
  - Neapolitan_Minor_Mode_V_G.txt | Start Note: G | Sequence: 1 3 1 1 2 2 2
  - Neapolitan_Minor_Mode_VI_Ab.txt | Start Note: Ab | Sequence: 3 1 1 2 2 2 1
  - Neapolitan_Minor_Mode_VII_B.txt | Start Note: B | Sequence: 1 1 2 2 2 1 3

09_Harmonic_Major_Modes
  - Harmonic_Major_C.txt | Start Note: C | Sequence: 2 2 1 2 1 3 1
  - Dorian_b5_D.txt | Start Note: D | Sequence: 2 1 2 1 3 1 2
  - Phrygian_b4_E.txt | Start Note: E | Sequence: 1 2 1 3 1 2 2
  - Lydian_b3_F.txt | Start Note: F | Sequence: 2 1 3 1 2 2 1
  - Mixolydian_b2_G.txt | Start Note: G | Sequence: 1 3 1 2 2 1 2
  - Lydian_Augmented_sharp2_Ab.txt | Start Note: Ab | Sequence: 3 1 2 2 1 2 1
  - Locrian_bb7_B.txt | Start Note: B | Sequence: 1 2 2 1 2 1 3

10_Arabic_Turkish_Middle_Eastern_C
  - Hijaz_C.txt | Start Note: C | Sequence: 1 3 1 2 1 2 2
  - Hijazkar_C.txt | Start Note: C | Sequence: 1 3 1 2 1 3 1
  - Bayati_Approximation_C.txt | Start Note: C | Sequence: 1 2 2 2 1 2 2
  - Nahawand_C.txt | Start Note: C | Sequence: 2 1 2 2 1 2 2
  - Rast_Approximation_C.txt | Start Note: C | Sequence: 2 2 1 2 2 2 1
  - Saba_Approximation_C.txt | Start Note: C | Sequence: 1 3 1 1 3 1 2
  - Kurd_C.txt | Start Note: C | Sequence: 1 2 2 2 1 2 2
  - Nikriz_C.txt | Start Note: C | Sequence: 1 3 1 2 1 3 1
  - Huzzam_Approximation_C.txt | Start Note: C | Sequence: 1 3 1 1 2 3 1
  - Suznak_C.txt | Start Note: C | Sequence: 2 2 1 2 1 3 1
  - Ussak_Approximation_C.txt | Start Note: C | Sequence: 1 2 2 2 1 2 2
  - Segah_Approximation_C.txt | Start Note: C | Sequence: 1 3 1 2 2 1 2
  - Persian_Scale_C.txt | Start Note: C | Sequence: 1 3 1 1 2 3 1
  - Byzantine_Double_Harmonic_C.txt | Start Note: C | Sequence: 1 3 1 2 1 3 1
  - Oriental_Scale_C.txt | Start Note: C | Sequence: 1 3 1 1 3 1 2
  - Arabic_Pentatonic_Approximation_C.txt | Start Note: C | Sequence: 2 1 4 2 3
  - Turkish_Huseyni_Approximation_C.txt | Start Note: C | Sequence: 2 1 2 2 1 2 2
  - Turkish_Nihavent_C.txt | Start Note: C | Sequence: 2 1 2 2 1 2 2
  - Turkish_Karcigar_Approximation_C.txt | Start Note: C | Sequence: 1 3 1 2 1 2 2

