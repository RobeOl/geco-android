GeCo K=3 Closed Triad Presets - Complete
========================================

Total presets: 496
Each preset is a closed triad: root-third-fifth-root.
The interval sequence contains three intervals and sums to 12.

01_Church_Modes_from_C_Major
  Ionian_C
    - 01_C_E_G_C.txt | C E G C | K=3: 4 3 5
    - 02_D_F_A_D.txt | D F A D | K=3: 3 4 5
    - 03_E_G_B_E.txt | E G B E | K=3: 3 4 5
    - 04_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 05_G_B_D_G.txt | G B D G | K=3: 4 3 5
    - 06_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 07_B_D_F_B.txt | B D F B | K=3: 3 3 6
  Dorian_D
    - 01_D_F_A_D.txt | D F A D | K=3: 3 4 5
    - 02_E_G_B_E.txt | E G B E | K=3: 3 4 5
    - 03_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 04_G_B_D_G.txt | G B D G | K=3: 4 3 5
    - 05_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 06_B_D_F_B.txt | B D F B | K=3: 3 3 6
    - 07_C_E_G_C.txt | C E G C | K=3: 4 3 5
  Phrygian_E
    - 01_E_G_B_E.txt | E G B E | K=3: 3 4 5
    - 02_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 03_G_B_D_G.txt | G B D G | K=3: 4 3 5
    - 04_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 05_B_D_F_B.txt | B D F B | K=3: 3 3 6
    - 06_C_E_G_C.txt | C E G C | K=3: 4 3 5
    - 07_D_F_A_D.txt | D F A D | K=3: 3 4 5
  Lydian_F
    - 01_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 02_G_B_D_G.txt | G B D G | K=3: 4 3 5
    - 03_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 04_B_D_F_B.txt | B D F B | K=3: 3 3 6
    - 05_C_E_G_C.txt | C E G C | K=3: 4 3 5
    - 06_D_F_A_D.txt | D F A D | K=3: 3 4 5
    - 07_E_G_B_E.txt | E G B E | K=3: 3 4 5
  Mixolydian_G
    - 01_G_B_D_G.txt | G B D G | K=3: 4 3 5
    - 02_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 03_B_D_F_B.txt | B D F B | K=3: 3 3 6
    - 04_C_E_G_C.txt | C E G C | K=3: 4 3 5
    - 05_D_F_A_D.txt | D F A D | K=3: 3 4 5
    - 06_E_G_B_E.txt | E G B E | K=3: 3 4 5
    - 07_F_A_C_F.txt | F A C F | K=3: 4 3 5
  Aeolian_A
    - 01_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 02_B_D_F_B.txt | B D F B | K=3: 3 3 6
    - 03_C_E_G_C.txt | C E G C | K=3: 4 3 5
    - 04_D_F_A_D.txt | D F A D | K=3: 3 4 5
    - 05_E_G_B_E.txt | E G B E | K=3: 3 4 5
    - 06_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 07_G_B_D_G.txt | G B D G | K=3: 4 3 5
  Locrian_B
    - 01_B_D_F_B.txt | B D F B | K=3: 3 3 6
    - 02_C_E_G_C.txt | C E G C | K=3: 4 3 5
    - 03_D_F_A_D.txt | D F A D | K=3: 3 4 5
    - 04_E_G_B_E.txt | E G B E | K=3: 3 4 5
    - 05_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 06_G_B_D_G.txt | G B D G | K=3: 4 3 5
    - 07_A_C_E_A.txt | A C E A | K=3: 3 4 5

02_Modes_of_A_Harmonic_Minor
  Harmonic_Minor_A
    - 01_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 02_B_D_F_B.txt | B D F B | K=3: 3 3 6
    - 03_C_E_Gsharp_C.txt | C E G# C | K=3: 4 4 4
    - 04_D_F_A_D.txt | D F A D | K=3: 3 4 5
    - 05_E_Gsharp_B_E.txt | E G# B E | K=3: 4 3 5
    - 06_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 07_Gsharp_B_D_Gsharp.txt | G# B D G# | K=3: 3 3 6
  Locrian_sharp6_B
    - 01_B_D_F_B.txt | B D F B | K=3: 3 3 6
    - 02_C_E_Gsharp_C.txt | C E G# C | K=3: 4 4 4
    - 03_D_F_A_D.txt | D F A D | K=3: 3 4 5
    - 04_E_Gsharp_B_E.txt | E G# B E | K=3: 4 3 5
    - 05_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 06_Gsharp_B_D_Gsharp.txt | G# B D G# | K=3: 3 3 6
    - 07_A_C_E_A.txt | A C E A | K=3: 3 4 5
  Ionian_sharp5_C
    - 01_C_E_Gsharp_C.txt | C E G# C | K=3: 4 4 4
    - 02_D_F_A_D.txt | D F A D | K=3: 3 4 5
    - 03_E_Gsharp_B_E.txt | E G# B E | K=3: 4 3 5
    - 04_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 05_Gsharp_B_D_Gsharp.txt | G# B D G# | K=3: 3 3 6
    - 06_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 07_B_D_F_B.txt | B D F B | K=3: 3 3 6
  Dorian_sharp4_D
    - 01_D_F_A_D.txt | D F A D | K=3: 3 4 5
    - 02_E_Gsharp_B_E.txt | E G# B E | K=3: 4 3 5
    - 03_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 04_Gsharp_B_D_Gsharp.txt | G# B D G# | K=3: 3 3 6
    - 05_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 06_B_D_F_B.txt | B D F B | K=3: 3 3 6
    - 07_C_E_Gsharp_C.txt | C E G# C | K=3: 4 4 4
  Phrygian_Dominant_E
    - 01_E_Gsharp_B_E.txt | E G# B E | K=3: 4 3 5
    - 02_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 03_Gsharp_B_D_Gsharp.txt | G# B D G# | K=3: 3 3 6
    - 04_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 05_B_D_F_B.txt | B D F B | K=3: 3 3 6
    - 06_C_E_Gsharp_C.txt | C E G# C | K=3: 4 4 4
    - 07_D_F_A_D.txt | D F A D | K=3: 3 4 5
  Lydian_sharp2_F
    - 01_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 02_Gsharp_B_D_Gsharp.txt | G# B D G# | K=3: 3 3 6
    - 03_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 04_B_D_F_B.txt | B D F B | K=3: 3 3 6
    - 05_C_E_Gsharp_C.txt | C E G# C | K=3: 4 4 4
    - 06_D_F_A_D.txt | D F A D | K=3: 3 4 5
    - 07_E_Gsharp_B_E.txt | E G# B E | K=3: 4 3 5
  Ultra_Locrian_Gsharp
    - 01_Gsharp_B_D_Gsharp.txt | G# B D G# | K=3: 3 3 6
    - 02_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 03_B_D_F_B.txt | B D F B | K=3: 3 3 6
    - 04_C_E_Gsharp_C.txt | C E G# C | K=3: 4 4 4
    - 05_D_F_A_D.txt | D F A D | K=3: 3 4 5
    - 06_E_Gsharp_B_E.txt | E G# B E | K=3: 4 3 5
    - 07_F_A_C_F.txt | F A C F | K=3: 4 3 5

03_Modes_of_A_Melodic_Minor
  Melodic_Minor_A
    - 01_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 02_B_D_Fsharp_B.txt | B D F# B | K=3: 3 4 5
    - 03_C_E_Gsharp_C.txt | C E G# C | K=3: 4 4 4
    - 04_D_Fsharp_A_D.txt | D F# A D | K=3: 4 3 5
    - 05_E_Gsharp_B_E.txt | E G# B E | K=3: 4 3 5
    - 06_Fsharp_A_C_Fsharp.txt | F# A C F# | K=3: 3 3 6
    - 07_Gsharp_B_D_Gsharp.txt | G# B D G# | K=3: 3 3 6
  Dorian_b2_B
    - 01_B_D_Fsharp_B.txt | B D F# B | K=3: 3 4 5
    - 02_C_E_Gsharp_C.txt | C E G# C | K=3: 4 4 4
    - 03_D_Fsharp_A_D.txt | D F# A D | K=3: 4 3 5
    - 04_E_Gsharp_B_E.txt | E G# B E | K=3: 4 3 5
    - 05_Fsharp_A_C_Fsharp.txt | F# A C F# | K=3: 3 3 6
    - 06_Gsharp_B_D_Gsharp.txt | G# B D G# | K=3: 3 3 6
    - 07_A_C_E_A.txt | A C E A | K=3: 3 4 5
  Lydian_Augmented_C
    - 01_C_E_Gsharp_C.txt | C E G# C | K=3: 4 4 4
    - 02_D_Fsharp_A_D.txt | D F# A D | K=3: 4 3 5
    - 03_E_Gsharp_B_E.txt | E G# B E | K=3: 4 3 5
    - 04_Fsharp_A_C_Fsharp.txt | F# A C F# | K=3: 3 3 6
    - 05_Gsharp_B_D_Gsharp.txt | G# B D G# | K=3: 3 3 6
    - 06_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 07_B_D_Fsharp_B.txt | B D F# B | K=3: 3 4 5
  Lydian_Dominant_D
    - 01_D_Fsharp_A_D.txt | D F# A D | K=3: 4 3 5
    - 02_E_Gsharp_B_E.txt | E G# B E | K=3: 4 3 5
    - 03_Fsharp_A_C_Fsharp.txt | F# A C F# | K=3: 3 3 6
    - 04_Gsharp_B_D_Gsharp.txt | G# B D G# | K=3: 3 3 6
    - 05_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 06_B_D_Fsharp_B.txt | B D F# B | K=3: 3 4 5
    - 07_C_E_Gsharp_C.txt | C E G# C | K=3: 4 4 4
  Mixolydian_b6_E
    - 01_E_Gsharp_B_E.txt | E G# B E | K=3: 4 3 5
    - 02_Fsharp_A_C_Fsharp.txt | F# A C F# | K=3: 3 3 6
    - 03_Gsharp_B_D_Gsharp.txt | G# B D G# | K=3: 3 3 6
    - 04_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 05_B_D_Fsharp_B.txt | B D F# B | K=3: 3 4 5
    - 06_C_E_Gsharp_C.txt | C E G# C | K=3: 4 4 4
    - 07_D_Fsharp_A_D.txt | D F# A D | K=3: 4 3 5
  Locrian_sharp2_Fsharp
    - 01_Fsharp_A_C_Fsharp.txt | F# A C F# | K=3: 3 3 6
    - 02_Gsharp_B_D_Gsharp.txt | G# B D G# | K=3: 3 3 6
    - 03_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 04_B_D_Fsharp_B.txt | B D F# B | K=3: 3 4 5
    - 05_C_E_Gsharp_C.txt | C E G# C | K=3: 4 4 4
    - 06_D_Fsharp_A_D.txt | D F# A D | K=3: 4 3 5
    - 07_E_Gsharp_B_E.txt | E G# B E | K=3: 4 3 5
  Altered_Super_Locrian_Gsharp
    - 01_Gsharp_B_D_Gsharp.txt | G# B D G# | K=3: 3 3 6
    - 02_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 03_B_D_Fsharp_B.txt | B D F# B | K=3: 3 4 5
    - 04_C_E_Gsharp_C.txt | C E G# C | K=3: 4 4 4
    - 05_D_Fsharp_A_D.txt | D F# A D | K=3: 4 3 5
    - 06_E_Gsharp_B_E.txt | E G# B E | K=3: 4 3 5
    - 07_Fsharp_A_C_Fsharp.txt | F# A C F# | K=3: 3 3 6

04_Pentatonic_and_Blues_C
  Major_Pentatonic_C
    - 01_C_E_A_C.txt | C E A C | K=3: 4 5 3
    - 02_D_G_C_D.txt | D G C D | K=3: 5 5 2
    - 03_E_A_D_E.txt | E A D E | K=3: 5 5 2
    - 04_G_C_E_G.txt | G C E G | K=3: 5 4 3
    - 05_A_D_G_A.txt | A D G A | K=3: 5 5 2
  Minor_Pentatonic_C
    - 01_C_F_Bb_C.txt | C F Bb C | K=3: 5 5 2
    - 02_Eb_G_C_Eb.txt | Eb G C Eb | K=3: 4 5 3
    - 03_F_Bb_Eb_F.txt | F Bb Eb F | K=3: 5 5 2
    - 04_G_C_F_G.txt | G C F G | K=3: 5 5 2
    - 05_Bb_Eb_G_Bb.txt | Bb Eb G Bb | K=3: 5 4 3
  Major_Blues_C
    - 01_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 02_D_E_A_D.txt | D E A D | K=3: 2 5 5
    - 03_Eb_G_C_Eb.txt | Eb G C Eb | K=3: 4 5 3
    - 04_E_A_D_E.txt | E A D E | K=3: 5 5 2
    - 05_G_C_Eb_G.txt | G C Eb G | K=3: 5 3 4
    - 06_A_D_E_A.txt | A D E A | K=3: 5 2 5
  Minor_Blues_C
    - 01_C_F_G_C.txt | C F G C | K=3: 5 2 5
    - 02_Eb_Gb_Bb_Eb.txt | Eb Gb Bb Eb | K=3: 3 4 5
    - 03_F_G_C_F.txt | F G C F | K=3: 2 5 5
    - 04_Gb_Bb_Eb_Gb.txt | Gb Bb Eb Gb | K=3: 4 5 3
    - 05_G_C_F_G.txt | G C F G | K=3: 5 5 2
    - 06_Bb_Eb_Gb_Bb.txt | Bb Eb Gb Bb | K=3: 5 3 4

05_Bebop_C
  Major_Bebop_C
    - 01_C_E_G_C.txt | C E G C | K=3: 4 3 5
    - 02_D_F_Ab_D.txt | D F Ab D | K=3: 3 3 6
    - 03_E_G_A_E.txt | E G A E | K=3: 3 2 7
    - 04_F_Ab_B_F.txt | F Ab B F | K=3: 3 3 6
    - 05_G_A_C_G.txt | G A C G | K=3: 2 3 7
    - 06_Ab_B_D_Ab.txt | Ab B D Ab | K=3: 3 3 6
    - 07_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 08_B_D_F_B.txt | B D F B | K=3: 3 3 6
  Dominant_Bebop_C
    - 01_C_E_G_C.txt | C E G C | K=3: 4 3 5
    - 02_D_F_A_D.txt | D F A D | K=3: 3 4 5
    - 03_E_G_Bb_E.txt | E G Bb E | K=3: 3 3 6
    - 04_F_A_B_F.txt | F A B F | K=3: 4 2 6
    - 05_G_Bb_C_G.txt | G Bb C G | K=3: 3 2 7
    - 06_A_B_D_A.txt | A B D A | K=3: 2 3 7
    - 07_Bb_C_E_Bb.txt | Bb C E Bb | K=3: 2 4 6
    - 08_B_D_F_B.txt | B D F B | K=3: 3 3 6
  Minor_Bebop_Dorian_Bebop_C
    - 01_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 02_D_F_Ab_D.txt | D F Ab D | K=3: 3 3 6
    - 03_Eb_G_A_Eb.txt | Eb G A Eb | K=3: 4 2 6
    - 04_F_Ab_Bb_F.txt | F Ab Bb F | K=3: 3 2 7
    - 05_G_A_C_G.txt | G A C G | K=3: 2 3 7
    - 06_Ab_Bb_D_Ab.txt | Ab Bb D Ab | K=3: 2 4 6
    - 07_A_C_Eb_A.txt | A C Eb A | K=3: 3 3 6
    - 08_Bb_D_F_Bb.txt | Bb D F Bb | K=3: 4 3 5
  Melodic_Minor_Bebop_C
    - 01_C_Eb_Gb_C.txt | C Eb Gb C | K=3: 3 3 6
    - 02_D_F_G_D.txt | D F G D | K=3: 3 2 7
    - 03_Eb_Gb_A_Eb.txt | Eb Gb A Eb | K=3: 3 3 6
    - 04_F_G_B_F.txt | F G B F | K=3: 2 4 6
    - 05_Gb_A_C_Gb.txt | Gb A C Gb | K=3: 3 3 6
    - 06_G_B_D_G.txt | G B D G | K=3: 4 3 5
    - 07_A_C_Eb_A.txt | A C Eb A | K=3: 3 3 6
    - 08_B_D_F_B.txt | B D F B | K=3: 3 3 6
  Harmonic_Minor_Bebop_C
    - 01_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 02_D_F_Ab_D.txt | D F Ab D | K=3: 3 3 6
    - 03_Eb_G_A_Eb.txt | Eb G A Eb | K=3: 4 2 6
    - 04_F_Ab_B_F.txt | F Ab B F | K=3: 3 3 6
    - 05_G_A_C_G.txt | G A C G | K=3: 2 3 7
    - 06_Ab_B_D_Ab.txt | Ab B D Ab | K=3: 3 3 6
    - 07_A_C_Eb_A.txt | A C Eb A | K=3: 3 3 6
    - 08_B_D_F_B.txt | B D F B | K=3: 3 3 6
  Bebop_Locrian_C
    - 01_C_Eb_Gb_C.txt | C Eb Gb C | K=3: 3 3 6
    - 02_Db_F_G_Db.txt | Db F G Db | K=3: 4 2 6
    - 03_Eb_Gb_Ab_Eb.txt | Eb Gb Ab Eb | K=3: 3 2 7
    - 04_F_G_Bb_F.txt | F G Bb F | K=3: 2 3 7
    - 05_Gb_Ab_C_Gb.txt | Gb Ab C Gb | K=3: 2 4 6
    - 06_G_Bb_Db_G.txt | G Bb Db G | K=3: 3 3 6
    - 07_Ab_C_Eb_Ab.txt | Ab C Eb Ab | K=3: 4 3 5
    - 08_Bb_Db_F_Bb.txt | Bb Db F Bb | K=3: 3 4 5
  Bebop_Altered_C
    - 01_C_Eb_Fsharp_C.txt | C Eb F# C | K=3: 3 3 6
    - 02_Db_E_Gsharp_Db.txt | Db E G# Db | K=3: 3 4 5
    - 03_Eb_Fsharp_Bb_Eb.txt | Eb F# Bb Eb | K=3: 3 4 5
    - 04_E_Gsharp_B_E.txt | E G# B E | K=3: 4 3 5
    - 05_Fsharp_Bb_C_Fsharp.txt | F# Bb C F# | K=3: 4 2 6
    - 06_Gsharp_B_Db_Gsharp.txt | G# B Db G# | K=3: 3 2 7
    - 07_Bb_C_Eb_Bb.txt | Bb C Eb Bb | K=3: 2 3 7
    - 08_B_Db_E_B.txt | B Db E B | K=3: 2 3 7
  Half_Whole_Bebop_Diminished_C
    - 01_C_Eb_Fsharp_C.txt | C Eb F# C | K=3: 3 3 6
    - 02_Db_E_G_Db.txt | Db E G Db | K=3: 3 3 6
    - 03_Eb_Fsharp_A_Eb.txt | Eb F# A Eb | K=3: 3 3 6
    - 04_E_G_Bb_E.txt | E G Bb E | K=3: 3 3 6
    - 05_Fsharp_A_C_Fsharp.txt | F# A C F# | K=3: 3 3 6
    - 06_G_Bb_Db_G.txt | G Bb Db G | K=3: 3 3 6
    - 07_A_C_Eb_A.txt | A C Eb A | K=3: 3 3 6
    - 08_Bb_Db_E_Bb.txt | Bb Db E Bb | K=3: 3 3 6

06_Symmetric_C
  Whole_Tone_C
    - 01_C_E_Gsharp_C.txt | C E G# C | K=3: 4 4 4
    - 02_D_Fsharp_Asharp_D.txt | D F# A# D | K=3: 4 4 4
    - 03_E_Gsharp_C_E.txt | E G# C E | K=3: 4 4 4
    - 04_Fsharp_Asharp_D_Fsharp.txt | F# A# D F# | K=3: 4 4 4
    - 05_Gsharp_C_E_Gsharp.txt | G# C E G# | K=3: 4 4 4
    - 06_Asharp_D_Fsharp_Asharp.txt | A# D F# A# | K=3: 4 4 4
  Chromatic_C
    - 01_C_D_E_C.txt | C D E C | K=3: 2 2 8
    - 02_Db_Eb_F_Db.txt | Db Eb F Db | K=3: 2 2 8
    - 03_D_E_Fsharp_D.txt | D E F# D | K=3: 2 2 8
    - 04_Eb_F_G_Eb.txt | Eb F G Eb | K=3: 2 2 8
    - 05_E_Fsharp_Ab_E.txt | E F# Ab E | K=3: 2 2 8
    - 06_F_G_A_F.txt | F G A F | K=3: 2 2 8
    - 07_Fsharp_Ab_Bb_Fsharp.txt | F# Ab Bb F# | K=3: 2 2 8
    - 08_G_A_B_G.txt | G A B G | K=3: 2 2 8
    - 09_Ab_Bb_C_Ab.txt | Ab Bb C Ab | K=3: 2 2 8
    - 10_A_B_Db_A.txt | A B Db A | K=3: 2 2 8
    - 11_Bb_C_D_Bb.txt | Bb C D Bb | K=3: 2 2 8
    - 12_B_Db_Eb_B.txt | B Db Eb B | K=3: 2 2 8
  Diminished_Whole_Half_C
    - 01_C_Eb_Gb_C.txt | C Eb Gb C | K=3: 3 3 6
    - 02_D_F_Ab_D.txt | D F Ab D | K=3: 3 3 6
    - 03_Eb_Gb_A_Eb.txt | Eb Gb A Eb | K=3: 3 3 6
    - 04_F_Ab_B_F.txt | F Ab B F | K=3: 3 3 6
    - 05_Gb_A_C_Gb.txt | Gb A C Gb | K=3: 3 3 6
    - 06_Ab_B_D_Ab.txt | Ab B D Ab | K=3: 3 3 6
    - 07_A_C_Eb_A.txt | A C Eb A | K=3: 3 3 6
    - 08_B_D_F_B.txt | B D F B | K=3: 3 3 6
  Diminished_Half_Whole_C
    - 01_C_Eb_Fsharp_C.txt | C Eb F# C | K=3: 3 3 6
    - 02_Db_E_G_Db.txt | Db E G Db | K=3: 3 3 6
    - 03_Eb_Fsharp_A_Eb.txt | Eb F# A Eb | K=3: 3 3 6
    - 04_E_G_Bb_E.txt | E G Bb E | K=3: 3 3 6
    - 05_Fsharp_A_C_Fsharp.txt | F# A C F# | K=3: 3 3 6
    - 06_G_Bb_Db_G.txt | G Bb Db G | K=3: 3 3 6
    - 07_A_C_Eb_A.txt | A C Eb A | K=3: 3 3 6
    - 08_Bb_Db_E_Bb.txt | Bb Db E Bb | K=3: 3 3 6

07_Neapolitan_Major_Modes
  Neapolitan_Major_C
    - 01_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 02_Db_F_A_Db.txt | Db F A Db | K=3: 4 4 4
    - 03_Eb_G_B_Eb.txt | Eb G B Eb | K=3: 4 4 4
    - 04_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 05_G_B_Db_G.txt | G B Db G | K=3: 4 2 6
    - 06_A_C_Eb_A.txt | A C Eb A | K=3: 3 3 6
    - 07_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
  Neapolitan_Major_Mode_II_Db
    - 01_Db_F_A_Db.txt | Db F A Db | K=3: 4 4 4
    - 02_Eb_G_B_Eb.txt | Eb G B Eb | K=3: 4 4 4
    - 03_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 04_G_B_Db_G.txt | G B Db G | K=3: 4 2 6
    - 05_A_C_Eb_A.txt | A C Eb A | K=3: 3 3 6
    - 06_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
    - 07_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
  Neapolitan_Major_Mode_III_Eb
    - 01_Eb_G_B_Eb.txt | Eb G B Eb | K=3: 4 4 4
    - 02_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 03_G_B_Db_G.txt | G B Db G | K=3: 4 2 6
    - 04_A_C_Eb_A.txt | A C Eb A | K=3: 3 3 6
    - 05_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
    - 06_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 07_Db_F_A_Db.txt | Db F A Db | K=3: 4 4 4
  Neapolitan_Major_Mode_IV_F
    - 01_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 02_G_B_Db_G.txt | G B Db G | K=3: 4 2 6
    - 03_A_C_Eb_A.txt | A C Eb A | K=3: 3 3 6
    - 04_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
    - 05_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 06_Db_F_A_Db.txt | Db F A Db | K=3: 4 4 4
    - 07_Eb_G_B_Eb.txt | Eb G B Eb | K=3: 4 4 4
  Neapolitan_Major_Mode_V_G
    - 01_G_B_Db_G.txt | G B Db G | K=3: 4 2 6
    - 02_A_C_Eb_A.txt | A C Eb A | K=3: 3 3 6
    - 03_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
    - 04_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 05_Db_F_A_Db.txt | Db F A Db | K=3: 4 4 4
    - 06_Eb_G_B_Eb.txt | Eb G B Eb | K=3: 4 4 4
    - 07_F_A_C_F.txt | F A C F | K=3: 4 3 5
  Neapolitan_Major_Mode_VI_A
    - 01_A_C_Eb_A.txt | A C Eb A | K=3: 3 3 6
    - 02_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
    - 03_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 04_Db_F_A_Db.txt | Db F A Db | K=3: 4 4 4
    - 05_Eb_G_B_Eb.txt | Eb G B Eb | K=3: 4 4 4
    - 06_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 07_G_B_Db_G.txt | G B Db G | K=3: 4 2 6
  Neapolitan_Major_Mode_VII_B
    - 01_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
    - 02_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 03_Db_F_A_Db.txt | Db F A Db | K=3: 4 4 4
    - 04_Eb_G_B_Eb.txt | Eb G B Eb | K=3: 4 4 4
    - 05_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 06_G_B_Db_G.txt | G B Db G | K=3: 4 2 6
    - 07_A_C_Eb_A.txt | A C Eb A | K=3: 3 3 6

08_Neapolitan_Minor_Modes
  Neapolitan_Minor_C
    - 01_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 02_Db_F_Ab_Db.txt | Db F Ab Db | K=3: 4 3 5
    - 03_Eb_G_B_Eb.txt | Eb G B Eb | K=3: 4 4 4
    - 04_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 05_G_B_Db_G.txt | G B Db G | K=3: 4 2 6
    - 06_Ab_C_Eb_Ab.txt | Ab C Eb Ab | K=3: 4 3 5
    - 07_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
  Neapolitan_Minor_Mode_II_Db
    - 01_Db_F_Ab_Db.txt | Db F Ab Db | K=3: 4 3 5
    - 02_Eb_G_B_Eb.txt | Eb G B Eb | K=3: 4 4 4
    - 03_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 04_G_B_Db_G.txt | G B Db G | K=3: 4 2 6
    - 05_Ab_C_Eb_Ab.txt | Ab C Eb Ab | K=3: 4 3 5
    - 06_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
    - 07_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
  Neapolitan_Minor_Mode_III_Eb
    - 01_Eb_G_B_Eb.txt | Eb G B Eb | K=3: 4 4 4
    - 02_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 03_G_B_Db_G.txt | G B Db G | K=3: 4 2 6
    - 04_Ab_C_Eb_Ab.txt | Ab C Eb Ab | K=3: 4 3 5
    - 05_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
    - 06_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 07_Db_F_Ab_Db.txt | Db F Ab Db | K=3: 4 3 5
  Neapolitan_Minor_Mode_IV_F
    - 01_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 02_G_B_Db_G.txt | G B Db G | K=3: 4 2 6
    - 03_Ab_C_Eb_Ab.txt | Ab C Eb Ab | K=3: 4 3 5
    - 04_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
    - 05_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 06_Db_F_Ab_Db.txt | Db F Ab Db | K=3: 4 3 5
    - 07_Eb_G_B_Eb.txt | Eb G B Eb | K=3: 4 4 4
  Neapolitan_Minor_Mode_V_G
    - 01_G_B_Db_G.txt | G B Db G | K=3: 4 2 6
    - 02_Ab_C_Eb_Ab.txt | Ab C Eb Ab | K=3: 4 3 5
    - 03_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
    - 04_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 05_Db_F_Ab_Db.txt | Db F Ab Db | K=3: 4 3 5
    - 06_Eb_G_B_Eb.txt | Eb G B Eb | K=3: 4 4 4
    - 07_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
  Neapolitan_Minor_Mode_VI_Ab
    - 01_Ab_C_Eb_Ab.txt | Ab C Eb Ab | K=3: 4 3 5
    - 02_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
    - 03_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 04_Db_F_Ab_Db.txt | Db F Ab Db | K=3: 4 3 5
    - 05_Eb_G_B_Eb.txt | Eb G B Eb | K=3: 4 4 4
    - 06_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 07_G_B_Db_G.txt | G B Db G | K=3: 4 2 6
  Neapolitan_Minor_Mode_VII_B
    - 01_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
    - 02_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 03_Db_F_Ab_Db.txt | Db F Ab Db | K=3: 4 3 5
    - 04_Eb_G_B_Eb.txt | Eb G B Eb | K=3: 4 4 4
    - 05_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 06_G_B_Db_G.txt | G B Db G | K=3: 4 2 6
    - 07_Ab_C_Eb_Ab.txt | Ab C Eb Ab | K=3: 4 3 5

09_Arabic_Turkish_Middle_Eastern_C
  Hijaz_C
    - 01_C_E_G_C.txt | C E G C | K=3: 4 3 5
    - 02_Db_F_Ab_Db.txt | Db F Ab Db | K=3: 4 3 5
    - 03_E_G_Bb_E.txt | E G Bb E | K=3: 3 3 6
    - 04_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 05_G_Bb_Db_G.txt | G Bb Db G | K=3: 3 3 6
    - 06_Ab_C_E_Ab.txt | Ab C E Ab | K=3: 4 4 4
    - 07_Bb_Db_F_Bb.txt | Bb Db F Bb | K=3: 3 4 5
  Hijazkar_C
    - 01_C_E_G_C.txt | C E G C | K=3: 4 3 5
    - 02_Db_F_Ab_Db.txt | Db F Ab Db | K=3: 4 3 5
    - 03_E_G_B_E.txt | E G B E | K=3: 3 4 5
    - 04_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 05_G_B_Db_G.txt | G B Db G | K=3: 4 2 6
    - 06_Ab_C_E_Ab.txt | Ab C E Ab | K=3: 4 4 4
    - 07_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
  Bayati_Approximation_C
    - 01_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 02_Db_F_Ab_Db.txt | Db F Ab Db | K=3: 4 3 5
    - 03_Eb_G_Bb_Eb.txt | Eb G Bb Eb | K=3: 4 3 5
    - 04_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 05_G_Bb_Db_G.txt | G Bb Db G | K=3: 3 3 6
    - 06_Ab_C_Eb_Ab.txt | Ab C Eb Ab | K=3: 4 3 5
    - 07_Bb_Db_F_Bb.txt | Bb Db F Bb | K=3: 3 4 5
  Nahawand_C
    - 01_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 02_D_F_Ab_D.txt | D F Ab D | K=3: 3 3 6
    - 03_Eb_G_Bb_Eb.txt | Eb G Bb Eb | K=3: 4 3 5
    - 04_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 05_G_Bb_D_G.txt | G Bb D G | K=3: 3 4 5
    - 06_Ab_C_Eb_Ab.txt | Ab C Eb Ab | K=3: 4 3 5
    - 07_Bb_D_F_Bb.txt | Bb D F Bb | K=3: 4 3 5
  Rast_Approximation_C
    - 01_C_E_G_C.txt | C E G C | K=3: 4 3 5
    - 02_D_F_A_D.txt | D F A D | K=3: 3 4 5
    - 03_E_G_B_E.txt | E G B E | K=3: 3 4 5
    - 04_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 05_G_B_D_G.txt | G B D G | K=3: 4 3 5
    - 06_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 07_B_D_F_B.txt | B D F B | K=3: 3 3 6
  Saba_Approximation_C
    - 01_C_E_Gb_C.txt | C E Gb C | K=3: 4 2 6
    - 02_Db_F_A_Db.txt | Db F A Db | K=3: 4 4 4
    - 03_E_Gb_Bb_E.txt | E Gb Bb E | K=3: 2 4 6
    - 04_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 05_Gb_Bb_Db_Gb.txt | Gb Bb Db Gb | K=3: 4 3 5
    - 06_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 07_Bb_Db_F_Bb.txt | Bb Db F Bb | K=3: 3 4 5
  Kurd_C
    - 01_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 02_Db_F_Ab_Db.txt | Db F Ab Db | K=3: 4 3 5
    - 03_Eb_G_Bb_Eb.txt | Eb G Bb Eb | K=3: 4 3 5
    - 04_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 05_G_Bb_Db_G.txt | G Bb Db G | K=3: 3 3 6
    - 06_Ab_C_Eb_Ab.txt | Ab C Eb Ab | K=3: 4 3 5
    - 07_Bb_Db_F_Bb.txt | Bb Db F Bb | K=3: 3 4 5
  Nikriz_C
    - 01_C_E_G_C.txt | C E G C | K=3: 4 3 5
    - 02_Db_F_Ab_Db.txt | Db F Ab Db | K=3: 4 3 5
    - 03_E_G_B_E.txt | E G B E | K=3: 3 4 5
    - 04_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 05_G_B_Db_G.txt | G B Db G | K=3: 4 2 6
    - 06_Ab_C_E_Ab.txt | Ab C E Ab | K=3: 4 4 4
    - 07_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
  Huzzam_Approximation_C
    - 01_C_E_Gb_C.txt | C E Gb C | K=3: 4 2 6
    - 02_Db_F_Ab_Db.txt | Db F Ab Db | K=3: 4 3 5
    - 03_E_Gb_B_E.txt | E Gb B E | K=3: 2 5 5
    - 04_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 05_Gb_B_Db_Gb.txt | Gb B Db Gb | K=3: 5 2 5
    - 06_Ab_C_E_Ab.txt | Ab C E Ab | K=3: 4 4 4
    - 07_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
  Suznak_C
    - 01_C_E_G_C.txt | C E G C | K=3: 4 3 5
    - 02_D_F_Ab_D.txt | D F Ab D | K=3: 3 3 6
    - 03_E_G_B_E.txt | E G B E | K=3: 3 4 5
    - 04_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 05_G_B_D_G.txt | G B D G | K=3: 4 3 5
    - 06_Ab_C_E_Ab.txt | Ab C E Ab | K=3: 4 4 4
    - 07_B_D_F_B.txt | B D F B | K=3: 3 3 6
  Ussak_Approximation_C
    - 01_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 02_Db_F_Ab_Db.txt | Db F Ab Db | K=3: 4 3 5
    - 03_Eb_G_Bb_Eb.txt | Eb G Bb Eb | K=3: 4 3 5
    - 04_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 05_G_Bb_Db_G.txt | G Bb Db G | K=3: 3 3 6
    - 06_Ab_C_Eb_Ab.txt | Ab C Eb Ab | K=3: 4 3 5
    - 07_Bb_Db_F_Bb.txt | Bb Db F Bb | K=3: 3 4 5
  Segah_Approximation_C
    - 01_C_E_G_C.txt | C E G C | K=3: 4 3 5
    - 02_Db_F_A_Db.txt | Db F A Db | K=3: 4 4 4
    - 03_E_G_Bb_E.txt | E G Bb E | K=3: 3 3 6
    - 04_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 05_G_Bb_Db_G.txt | G Bb Db G | K=3: 3 3 6
    - 06_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 07_Bb_Db_F_Bb.txt | Bb Db F Bb | K=3: 3 4 5
  Persian_Scale_C
    - 01_C_E_Gb_C.txt | C E Gb C | K=3: 4 2 6
    - 02_Db_F_Ab_Db.txt | Db F Ab Db | K=3: 4 3 5
    - 03_E_Gb_B_E.txt | E Gb B E | K=3: 2 5 5
    - 04_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 05_Gb_B_Db_Gb.txt | Gb B Db Gb | K=3: 5 2 5
    - 06_Ab_C_E_Ab.txt | Ab C E Ab | K=3: 4 4 4
    - 07_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
  Byzantine_Double_Harmonic_C
    - 01_C_E_G_C.txt | C E G C | K=3: 4 3 5
    - 02_Db_F_Ab_Db.txt | Db F Ab Db | K=3: 4 3 5
    - 03_E_G_B_E.txt | E G B E | K=3: 3 4 5
    - 04_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 05_G_B_Db_G.txt | G B Db G | K=3: 4 2 6
    - 06_Ab_C_E_Ab.txt | Ab C E Ab | K=3: 4 4 4
    - 07_B_Db_F_B.txt | B Db F B | K=3: 2 4 6
  Oriental_Scale_C
    - 01_C_E_Gb_C.txt | C E Gb C | K=3: 4 2 6
    - 02_Db_F_A_Db.txt | Db F A Db | K=3: 4 4 4
    - 03_E_Gb_Bb_E.txt | E Gb Bb E | K=3: 2 4 6
    - 04_F_A_C_F.txt | F A C F | K=3: 4 3 5
    - 05_Gb_Bb_Db_Gb.txt | Gb Bb Db Gb | K=3: 4 3 5
    - 06_A_C_E_A.txt | A C E A | K=3: 3 4 5
    - 07_Bb_Db_F_Bb.txt | Bb Db F Bb | K=3: 3 4 5
  Arabic_Pentatonic_Approximation_C
    - 01_C_Eb_A_C.txt | C Eb A C | K=3: 3 6 3
    - 02_D_G_C_D.txt | D G C D | K=3: 5 5 2
    - 03_Eb_A_D_Eb.txt | Eb A D Eb | K=3: 6 5 1
    - 04_G_C_Eb_G.txt | G C Eb G | K=3: 5 3 4
    - 05_A_D_G_A.txt | A D G A | K=3: 5 5 2
  Turkish_Huseyni_Approximation_C
    - 01_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 02_D_F_Ab_D.txt | D F Ab D | K=3: 3 3 6
    - 03_Eb_G_Bb_Eb.txt | Eb G Bb Eb | K=3: 4 3 5
    - 04_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 05_G_Bb_D_G.txt | G Bb D G | K=3: 3 4 5
    - 06_Ab_C_Eb_Ab.txt | Ab C Eb Ab | K=3: 4 3 5
    - 07_Bb_D_F_Bb.txt | Bb D F Bb | K=3: 4 3 5
  Turkish_Nihavent_C
    - 01_C_Eb_G_C.txt | C Eb G C | K=3: 3 4 5
    - 02_D_F_Ab_D.txt | D F Ab D | K=3: 3 3 6
    - 03_Eb_G_Bb_Eb.txt | Eb G Bb Eb | K=3: 4 3 5
    - 04_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 05_G_Bb_D_G.txt | G Bb D G | K=3: 3 4 5
    - 06_Ab_C_Eb_Ab.txt | Ab C Eb Ab | K=3: 4 3 5
    - 07_Bb_D_F_Bb.txt | Bb D F Bb | K=3: 4 3 5
  Turkish_Karcigar_Approximation_C
    - 01_C_E_G_C.txt | C E G C | K=3: 4 3 5
    - 02_Db_F_Ab_Db.txt | Db F Ab Db | K=3: 4 3 5
    - 03_E_G_Bb_E.txt | E G Bb E | K=3: 3 3 6
    - 04_F_Ab_C_F.txt | F Ab C F | K=3: 3 4 5
    - 05_G_Bb_Db_G.txt | G Bb Db G | K=3: 3 3 6
    - 06_Ab_C_E_Ab.txt | Ab C E Ab | K=3: 4 4 4
    - 07_Bb_Db_F_Bb.txt | Bb Db F Bb | K=3: 3 4 5
